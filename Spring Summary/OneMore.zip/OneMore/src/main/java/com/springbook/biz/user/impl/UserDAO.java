package com.springbook.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.springbook.biz.common.JDBCUtil;
import com.springbook.biz.user.UserVO;

@Repository("userDAO")
public class UserDAO {
	private Connection con;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	private final String USER_GET = "select * from users where userid=? and userpw=?";
	
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		try {
			System.out.println("===> JDBC로 getUser() 기능 처리");
			con = JDBCUtil.getConnection();
			stmt = con.prepareStatement(USER_GET);
			stmt.setString(1, vo.getUserid());
			stmt.setString(2, vo.getUserpw());
			rs=stmt.executeQuery();
			if(rs.next()) {
				user = new UserVO();
				user.setIdx(rs.getInt("idx"));
				user.setUname(rs.getString("uname"));
				user.setUserid(rs.getString("userid"));
				user.setUserpw(rs.getString("userpw"));
				user.setUstat(rs.getInt("ustat"));
				user.setUauth(rs.getInt("uauth"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
}
