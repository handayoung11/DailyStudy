package com.springbook.biz.board;

import java.util.List;

import com.springbook.biz.board.BoardVO;

public interface BoardService {

	// CRUD 기능의 메서드 구현
	
	void insertBoard(BoardVO vo);

	void updateBoard(BoardVO vo);

	void deleteBoard(BoardVO vo);

	BoardVO getBoard(BoardVO vo);

	List<BoardVO> getBoardList();

}