package com.springbook.ioc.injection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CollectionBeanClient {
	public static void main(String[] args) {
//		ApplicationContext con = new GenericXmlApplicationContext("applicationContext.xml");
//		CollectionBean bean = (CollectionBean)con.getBean("collectionBean");
//		Properties map = bean.getAddressList();
//		Set<Object> keySet = map.keySet();
//		for(Object key : keySet) {
//			System.out.println(key + ": " + map.get(key));
//		}
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:orcl";
			String user = "project1";
			String pw = "Test1234";
			Connection con = DriverManager.getConnection(url, user, pw);
			PreparedStatement stmt = con.prepareStatement("select * from users where idx = ?");
			//1. executeQuery메서드를 통해 select문으로 검색
			//2. 반환값 rs
			//3. nex메서드로 커서 옮기기
			//4. get메서드로 값을 받기 BOARD_SEQ.nextval
			
			// select * from users where idx = '51'
			stmt.setString(1, "51");
//			stmt.setString(2, "51");
//			stmt.setString(3, "51");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				System.out.print(rs.getString("idx"));
				System.out.print(rs.getString("uname"));
				System.out.print(rs.getString("userid"));
				System.out.print(rs.getString("userpw"));
				System.out.print(rs.getString("uemail"));
				System.out.print(rs.getString("ustat"));
				System.out.print(rs.getString("uauth"));
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
