package com.springbook.biz.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class BoardServiceClient {

	public static void main(String[] args) {
		AbstractApplicationContext con = new GenericXmlApplicationContext("applicationContext.xml");
//		BoardDAOSpring boardService = (BoardDAOSpring)con.getBean("boardDAOSpring");
		BoardService boardService = (BoardService)con.getBean("boardService");
		BoardVO vo = new BoardVO();
		vo.setIdx(100);
		vo.setTitle("임시 제목");
		vo.setWriter(1);
		vo.setContent("임시내용..........");
//		boardService.insertBoard(vo);
		
		List<BoardVO> boardList = boardService.getBoardList();
		for(BoardVO board : boardList) {
			System.out.println(board);
			System.out.println("---> " + boardService.getBoard(board));
			break;
		}
		
		con.close();
	}
	
}
