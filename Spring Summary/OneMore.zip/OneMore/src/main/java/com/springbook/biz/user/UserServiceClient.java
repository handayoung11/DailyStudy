package com.springbook.biz.user;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class UserServiceClient {
	public static void main(String[] args) {
		AbstractApplicationContext con = new GenericXmlApplicationContext("applicationContext.xml");
		UserService user = (UserService)con.getBean("userService");
		UserVO vo = new UserVO();
		vo.setUserid("user");
		vo.setUserpw("1234");
//		UserVO loger = user.getUser(vo);
//		if(loger != null) {
//			System.out.println(loger.getUname() + "님 환영합니다.");
//		} else {
//			System.out.println("로그인 실패");
//		}
		con.close();
	}
}
