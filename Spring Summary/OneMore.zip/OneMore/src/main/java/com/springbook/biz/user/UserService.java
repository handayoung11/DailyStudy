package com.springbook.biz.user;

import com.springbook.biz.user.UserVO;

public interface UserService {

	UserVO getUser(UserVO vo);

}