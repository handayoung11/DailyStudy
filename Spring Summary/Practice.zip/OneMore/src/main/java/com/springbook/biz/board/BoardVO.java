package com.springbook.biz.board;

import java.sql.Date;

public class BoardVO {
	private int idx, writer, see, stat;
	private String title, content;
	private Date date;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getWriter() {
		return writer;
	}
	public void setWriter(int writer) {
		this.writer = writer;
	}
	public int getSee() {
		return see;
	}
	public void setSee(int see) {
		this.see = see;
	}
	public int getStat() {
		return stat;
	}
	public void setStat(int stat) {
		this.stat = stat;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "BoardVO [idx=" + idx + ", writer=" + writer + ", see=" + see + ", stat=" + stat + ", title=" + title
				+ ", content=" + content + ", date=" + date + "]";
	}
	
}
